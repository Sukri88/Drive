# ClaimLite V1.0.1
Earn Crypto Web Script 

# Get your API for Audio Captcha
  - http://assemblyai.com/

Auto Installion Of Modules

Manual installation

 - install python [_pkg install python_]
 
 - _pip install requests_

 - _pip install bs4_
 
 - _pip install requests_toolbelt_

 # Faucet Link
 - https://shorturl.at/AEKQ3
